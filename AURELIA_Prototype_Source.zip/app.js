(()=>{
 'use strict';
 const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
 const app=$('#app');
 let lang='ar',page='overview',galleryFilter='all',lightboxIndex=0,currentGallery=GALLERY_ITEMS.slice();
 let currentZone='garden',currentScene='garden',yaw=0,autoSpin=false,spinFrame=0,draggingTour=false,lastPointerX=0,lastTick=0;
 let mapScale=1,mapX=0,mapY=0,mapDragging=false,mapPointer=null;
 const cache={}, loadedPhotos={};let toastTimer=0;
 const t=k=>WORDS[lang][k]??k;
 function safeSrc(k){return loadedPhotos[k]||ART[k]}
 function notify(msg){const el=$('#toast');el.textContent=msg;el.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('visible'),2200)}
 function setLang(newLang){
   lang=newLang;app.dataset.lang=lang;document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';
   $('#langAr').classList.toggle('active',lang==='ar');$('#langEn').classList.toggle('active',lang==='en');
   $$('[data-i18n]').forEach(el=>{el.textContent=t(el.dataset.i18n)});
   renderFilters();renderGallery();renderZone();updateTourText();renderThumbs();renderHotspots();
   if(!$('#lightbox').hidden) renderLightbox();
 }
 function go(to){
   if(!['overview','map','gallery','video','tour'].includes(to))return;
   if(page==='video'&&to!=='video')pauseVideo();
   page=to;
   $('.demo-flag').style.display=to==='overview'?'':'none';
   $$('.page').forEach(p=>{const active=p.id==='page-'+to;p.classList.toggle('active',active);p.setAttribute('aria-hidden',String(!active))});
   $$('.nav-btn').forEach(b=>{b.classList.toggle('active',b.dataset.go===to);b.setAttribute('aria-current',b.dataset.go===to?'page':'false')});
   if(to==='tour'){setTimeout(()=>{resizeTour();renderHotspots();renderThumbs()},35)}
   if(to==='map')setTimeout(renderZone,30);
 }
 function setImage(el,key){el.src=safeSrc(key);el.dataset.art=key}
 function preloadPhotos(){
   Object.entries(PHOTO_URLS).forEach(([key,url])=>{
     const img=new Image();img.decoding='async';
     img.onload=()=>{
       if(img.naturalWidth<300)return;
       loadedPhotos[key]=url;
       $$("img[data-art='"+key+"']").forEach(el=>{el.src=url});
       if(key===currentZone)$('#mapPlacePhoto').style.backgroundImage=`url("${url}")`;
       if(key===currentScene){cache[key]=img;if(page==='tour')drawPanorama()}
     };
     img.onerror=()=>{};
     img.src=url;
   });
 }
 // GALLERY
 const categories=['all','exterior','interior','amenities'];
 function renderFilters(){const wrap=$('#galleryFilters');wrap.innerHTML='';categories.forEach(cat=>{
   const b=document.createElement('button');b.className='chip'+(galleryFilter===cat?' active':'');b.textContent=t(cat);b.setAttribute('aria-pressed',String(galleryFilter===cat));
   b.addEventListener('click',()=>{galleryFilter=cat;renderFilters();renderGallery()});wrap.appendChild(b);
 })}
 function renderGallery(){
   currentGallery=GALLERY_ITEMS.filter(x=>galleryFilter==='all'||x.category===galleryFilter);
   const grid=$('#galleryGrid');grid.innerHTML='';
   currentGallery.forEach((item,i)=>{
     const b=document.createElement('button');b.className='gallery-card';b.setAttribute('aria-label',t(item.title));
     b.innerHTML='<img loading="lazy" alt="" /><div class="gallery-info"><span><strong></strong><small></small></span><span class="gallery-expand"><svg class="icon"><use href="#ic-expand"/></svg></span></div>';
     setImage(b.querySelector('img'),item.id);b.querySelector('strong').textContent=t(item.title);b.querySelector('small').textContent=item.subtitle;
     b.addEventListener('click',()=>{lightboxIndex=i;renderLightbox();$('#lightbox').hidden=false});grid.appendChild(b);
   });
 }
 function renderLightbox(){if(!currentGallery.length)return;const item=currentGallery[(lightboxIndex+currentGallery.length)%currentGallery.length];
   setImage($('#lightboxImage'),item.id);$('#lightboxTitle').textContent=t(item.title);$('#lightboxSubtitle').textContent=`${String(lightboxIndex+1).padStart(2,'0')} / ${String(currentGallery.length).padStart(2,'0')}  ·  AURELIA RESIDENCES`;
 }
 function lightboxStep(direction){lightboxIndex=(lightboxIndex+direction+currentGallery.length)%currentGallery.length;renderLightbox()}
 function closeLightbox(){$('#lightbox').hidden=true}
 // INTERACTIVE MASTERPLAN
 function renderZone(){const z=SCENES[currentZone];$('#mapPlaceName').textContent=t(z.label);$('#mapPlaceDesc').textContent=t(z.label+'Desc');$('#mapPlaceNum').textContent=z.num+' / 04';
   $('#mapPlacePhoto').style.backgroundImage=`linear-gradient(0deg,#07141a55,#07141a05),url("${safeSrc(z.art)}")`;
   $$('[data-pin]').forEach(p=>p.classList.toggle('selected',p.dataset.pin===currentZone));
 }
 function applyMap(){mapScale=Math.max(1,Math.min(mapScale,3.2));const l=130*(mapScale-1),v=95*(mapScale-1);mapX=Math.max(-l,Math.min(mapX,l));mapY=Math.max(-v,Math.min(mapY,v));$('#mapArt').style.transform=`translate(${mapX}px,${mapY}px) scale(${mapScale})`}
 function zoomMap(delta){mapScale+=delta;applyMap()}
 // TOUR CANVAS – horizontal panorama simulation, replaceable with Marzipano/360 tiles in production
 const tour=$('#tourView'),canvas=$('#tourCanvas'),ctx=canvas.getContext('2d',{alpha:false});
 let canvasW=0,canvasH=0;
 function imageForScene(id){
   const key=SCENES[id].art;if(cache[key]?.complete&&cache[key].naturalWidth)return cache[key];
   const im=new Image();im.onload=()=>{if(currentScene===id)drawPanorama()};im.src=safeSrc(key);cache[key]=im;return im;
 }
 function resizeTour(){const box=tour.getBoundingClientRect();const dpr=Math.min(window.devicePixelRatio||1,1.5);
   const w=Math.max(1,Math.floor(box.width)),h=Math.max(1,Math.floor(box.height));if(w===canvasW&&h===canvasH)return;
   canvasW=w;canvasH=h;canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);drawPanorama();
 }
 const fov=2.68; // demonstration cylindrical horizontal viewport
 function drawPanorama(){
   if(!canvasW||!canvasH)return;
   const im=imageForScene(currentScene),dpr=canvas.width/canvasW;
   ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,canvasW,canvasH);ctx.fillStyle='#223541';ctx.fillRect(0,0,canvasW,canvasH);
   if(!im.complete||!im.naturalWidth)return;
   const sourceW=im.naturalWidth,sourceH=im.naturalHeight;
   // Render seamless horizontal panning using narrow image strips.
   const step=3;
   for(let x=0;x<canvasW;x+=step){
     const angle=yaw+(x/canvasW-.5)*fov;
     const u=((angle/(Math.PI*2)+.5)%1+1)%1;
     const sx=Math.min(sourceW-2,u*sourceW),sample=Math.min(sourceW-sx,Math.max(2,sourceW*fov/(Math.PI*2)*(step/canvasW)));
     ctx.drawImage(im,sx,0,sample,sourceH,x,0,Math.min(step+1,canvasW-x),canvasH);
   }
 }
 function normalize(a){while(a>Math.PI)a-=Math.PI*2;while(a< -Math.PI)a+=Math.PI*2;return a}
 function renderHotspots(){const wrap=$('#hotspotsLayer');wrap.innerHTML='';const s=SCENES[currentScene];s.hotspots.forEach(h=>{
     const b=document.createElement('button');b.className='tour-hotspot';b.dataset.angle=h.yaw;b.dataset.target=h.target;b.innerHTML='<span class="hot-circle"><svg class="icon"><use href="#ic-arrow"/></svg></span><span></span>';
     b.querySelector('span:last-child').textContent=t(h.target);b.addEventListener('click',(e)=>{e.stopPropagation();changeScene(h.target)});wrap.appendChild(b)
   });positionHotspots()
 }
 function positionHotspots(){
   $$('.tour-hotspot').forEach(b=>{const delta=normalize(Number(b.dataset.angle)-yaw),portion=delta/fov+.5,visible=Math.abs(delta)<fov*.46;
     b.style.display=visible?'flex':'none';b.style.left=`${portion*100}%`;b.style.top='56%';
   })
 }
 function updateTourText(){$('#sceneHeading').textContent=t(currentScene);$('#autoRotate').classList.toggle('active',autoSpin)}
 function renderThumbs(){const box=$('#sceneThumbs');box.innerHTML='';Object.entries(SCENES).forEach(([id,s])=>{
   const b=document.createElement('button');b.className='scene-thumb'+(currentScene===id?' active':'');b.innerHTML='<img alt=""/><span></span>';setImage(b.querySelector('img'),s.art);b.querySelector('span').textContent=t(s.label);
   b.addEventListener('click',()=>changeScene(id));box.appendChild(b)
 })}
 function changeScene(id){if(!SCENES[id])return;currentScene=id;yaw=0;imageForScene(id);updateTourText();renderThumbs();renderHotspots();drawPanorama()}
 function turnBy(delta){yaw=normalize(yaw+delta);drawPanorama();positionHotspots()}
 function rotationFrame(now){if(!autoSpin)return;if(page==='tour'&&!draggingTour){if(lastTick)turnBy(Math.min(.012,(now-lastTick)*.00013))}lastTick=now;spinFrame=requestAnimationFrame(rotationFrame)}
 function setAutoRotation(on){autoSpin=on;$('#autoRotate').classList.toggle('active',on);cancelAnimationFrame(spinFrame);lastTick=0;if(on)spinFrame=requestAnimationFrame(rotationFrame)}
 // PLAYABLE LOCAL VIDEO
 const video=$('#showreel'),videoPlayer=$('#videoPlayer');
 function pauseVideo(){if(!video.paused)video.pause()}
 async function toggleVideo(){
   try{if(video.paused)await video.play();else video.pause()}catch(e){notify(t('tapToPlay'))}
 }
 function syncVideo(){let playing=!video.paused;videoPlayer.classList.toggle('playing',playing);$('#videoIcon').setAttribute('href',playing?'#ic-pause':'#ic-play');$('#bigPlay').querySelector('use').setAttribute('href',playing?'#ic-pause':'#ic-play')}
 const fmt=(x)=>{if(!Number.isFinite(x))x=0;return String(Math.floor(x/60)).padStart(2,'0')+':'+String(Math.floor(x%60)).padStart(2,'0')};
 // EVENTS
 $$('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
 $('#homeBtn').addEventListener('click',()=>go('overview'));
 $('#langAr').addEventListener('click',()=>setLang('ar'));$('#langEn').addEventListener('click',()=>setLang('en'));
 $('#fullscreenBtn').addEventListener('click',()=>{if(document.fullscreenElement)document.exitFullscreen();else document.documentElement.requestFullscreen?.().catch(()=>notify(t('fullscreenFail')))});
 $('#lightboxClose').addEventListener('click',closeLightbox);$('#lightboxPrev').addEventListener('click',()=>lightboxStep(-1));$('#lightboxNext').addEventListener('click',()=>lightboxStep(1));
 $('#lightbox').addEventListener('click',(e)=>{if(e.target.id==='lightbox')closeLightbox()});
 $$('[data-pin]').forEach(p=>p.addEventListener('click',()=>{currentZone=p.dataset.pin;renderZone()}));
 $('#exploreSelected').addEventListener('click',()=>{changeScene(currentZone);go('tour')});
 $('#zoomIn').addEventListener('click',()=>zoomMap(.35));$('#zoomOut').addEventListener('click',()=>zoomMap(-.35));$('#zoomReset').addEventListener('click',()=>{mapScale=1;mapX=0;mapY=0;applyMap()});
 const mapStage=$('#mapStage');
 mapStage.addEventListener('pointerdown',(e)=>{if(e.target.closest('button'))return;mapDragging=true;mapPointer={x:e.clientX,y:e.clientY};mapStage.classList.add('is-panning');mapStage.setPointerCapture(e.pointerId)});
 mapStage.addEventListener('pointermove',(e)=>{if(!mapDragging)return;mapX+=e.clientX-mapPointer.x;mapY+=e.clientY-mapPointer.y;mapPointer={x:e.clientX,y:e.clientY};applyMap()});
 function mapUp(){mapDragging=false;mapStage.classList.remove('is-panning')}
 mapStage.addEventListener('pointerup',mapUp);mapStage.addEventListener('pointercancel',mapUp);
 mapStage.addEventListener('wheel',(e)=>{e.preventDefault();zoomMap(e.deltaY<0?.2:-.2)},{passive:false});
 tour.addEventListener('pointerdown',(e)=>{if(e.target.closest('button'))return;draggingTour=true;lastPointerX=e.clientX;tour.classList.add('dragging');tour.setPointerCapture(e.pointerId)});
 tour.addEventListener('pointermove',(e)=>{if(!draggingTour)return;let dx=e.clientX-lastPointerX;lastPointerX=e.clientX;turnBy(-dx/tour.clientWidth*fov*1.1)});
 function tourUp(){draggingTour=false;tour.classList.remove('dragging')}
 tour.addEventListener('pointerup',tourUp);tour.addEventListener('pointercancel',tourUp);
 $('#autoRotate').addEventListener('click',()=>{setAutoRotation(!autoSpin);notify(t(autoSpin?'autoOn':'autoOff'))});
 $('#bigPlay').addEventListener('click',toggleVideo);$('#smallPlay').addEventListener('click',toggleVideo);
 video.addEventListener('click',toggleVideo);
 video.addEventListener('play',syncVideo);video.addEventListener('pause',syncVideo);video.addEventListener('ended',syncVideo);
 video.addEventListener('loadedmetadata',()=>$('#duration').textContent=fmt(video.duration));
 video.addEventListener('timeupdate',()=>{let n=video.duration>0?100*video.currentTime/video.duration:0;$('#currentTime').textContent=fmt(video.currentTime);$('#videoProgress').value=n});
 $('#videoProgress').addEventListener('input',(e)=>{if(video.duration>0)video.currentTime=Number(e.target.value)*video.duration/100});
 $('#videoFullscreen').addEventListener('click',()=>video.requestFullscreen?.().catch(()=>notify(t('fullscreenFail'))));
 document.addEventListener('keydown',(e)=>{
   if(e.key==='Escape'){closeLightbox();if(document.fullscreenElement)document.exitFullscreen();return}
   if(!$('#lightbox').hidden){if(e.key==='ArrowLeft')lightboxStep(-1);else if(e.key==='ArrowRight')lightboxStep(1);return}
   if(page==='tour'&&e.key==='ArrowLeft')turnBy(-.15);else if(page==='tour'&&e.key==='ArrowRight')turnBy(.15);
 });
 window.addEventListener('resize',()=>{if(page==='tour')resizeTour()});
 // Kiosk restores the home page after prolonged inactivity. Any interaction resets the clock.
 let idleTimer;function resetIdle(){clearTimeout(idleTimer);idleTimer=setTimeout(()=>{if(page==='video')pauseVideo();setAutoRotation(false);go('overview')},4*60*1000)}
 ['pointerdown','keydown','wheel','touchstart'].forEach(type=>document.addEventListener(type,resetIdle,{passive:true}));resetIdle();
 $('#heroImg').src=safeSrc('hero');$('#heroImg').dataset.art='hero';video.poster=safeSrc('hero');
 Object.keys(SCENES).forEach(id=>imageForScene(id));
 setLang('ar');renderFilters();renderGallery();renderZone();renderThumbs();go('overview');
 // The optional Unsplash photo swap only occurs after a successful load. Entire demo stays functional offline.
 preloadPhotos();
})();
